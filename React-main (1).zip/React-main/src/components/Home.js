import React from 'react';
import '../styles/Home.css';

const Home = () => {
  return (
    <div id="home">
        <div id="col">
            <div id="row-1">
                <div id="box"></div>
                <div id="box"></div>
                <div id="box"></div>
            </div>
            <div id="row-1">
                <div id="box"></div>
                <div id="box"></div>
                <div id="box"></div>
            </div>
            <div id="row-1">
                <div id="box"></div>
                <div id="box"></div>
                <div id="box"></div>
            </div>
        </div>
    </div>
  )
}

export default Home