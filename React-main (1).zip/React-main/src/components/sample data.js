const data = {
    products: [
      {
        id: '1',
        name: 'book shelf',
        price: 20000,
        image: 'https://wakefit-co.s3.ap-south-1.amazonaws.com/img/bookshelves/brooks/0.jpg',
      },
      {
        id: '2',
        name: 'laptop',
        price: 23222,
        image: 'https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE4AQrc?ver=9a49&q=90&m=6&h=270&w=270&b=%23FFFFFFFF&f=jpg&o=f&aim=true',
      },
      {
        id: '3',
        name: 'sneakers',
        price: 10000,
        image: 'https://i.insider.com/59c166d92488491d980855ee?width=600&format=jpeg&auto=webp',
      },
    ],
  };
  export default data;